import React from 'react'

const Home = () => {
  return (
    <div>
      тут пока что ничего нет
    </div>
  )
}

export default Home
