import React, { Component } from 'react'


export class Order extends Component {
  render() {
    return (
      <div className='item'>
        
      </div>
    )
  }
}

export default Order