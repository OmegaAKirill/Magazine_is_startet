import React from 'react'

const AddEdit = () => {
  return (
    <div>
        <h2>AddEdit</h2>
    </div>
  )
}

export default AddEdit