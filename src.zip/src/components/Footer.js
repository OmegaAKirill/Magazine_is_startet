import React from 'react'

export default function Footer() {
  return (
    <footer>
        все права защещены 
    </footer>
  )
}
