import React, {useState} from 'react';
import {Link, useLocation} from 'react-router-dom'
import { FaShoppingCart } from 'react-icons/fa' //тут пропиши npm i react-icons
import Order from './Order';

const Header = (props) => {
    let [cartOpen, setCartOpen] = useState(false)
    const [activeTab, setActiveTab] = useState("Home")
    return (
        <header>
            <div>
                <span className='logo'>Мир одежды</span>
                <ul className='nav'>
                <Link to="/">
                    <p className={`${activeTab === "Home" ? "active" : ""}`} onClick={() => setActiveTab("Home")} >изменить карту</p>
                </Link>
                <Link to="/add">
                    <p className={`${activeTab === "AddContact" ? "active" : ""}`} onClick={() => setActiveTab("AddContact")}>создать карту</p>
                </Link>
                <Link to="/">
                    <p className={`${activeTab === "About" ? "active" : ""}`} onClick={() => setActiveTab("About")}>войти</p>
                </Link>
                </ul>
                <FaShoppingCart onClick={() =>setCartOpen(cartOpen = !cartOpen)} className={`shop-cart-button ${cartOpen && 'active'}`}/>

                {cartOpen && (
                    <div className='shop-cart'>
                        {props.orders.length > 0 ?
                         showOrders(props) : showNothing()}
                    </div>
                )}
            </div>
            <div className='presentation'></div>
        </header>
    );
}

const showOrders = (props) =>{
    let summa = 0
    props.orders.forEach(el => summa += Number.parseFloat(el.price));
    return(
        <div>
            {props.orders.map(el => (
                <Order onDelete={props.onDelete} key={el.id} item={el} />
            ))}
            <p className='summa'>Сумма: {new Intl.NumberFormat().format(summa)}$</p>
        </div>
    )
}

const showNothing =()=>{
    return(
        <div className='empty'>
            <h2>корзина пуста</h2>
        </div>
    )

    
}

export default Header;
