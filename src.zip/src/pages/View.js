import React from 'react'

const View = () => {
  return (
    <div>
        <h2>View</h2>
    </div>
  )
}

export default View